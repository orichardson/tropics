divisor_view(G)
# *** Spyder Python Console History Log ***
divisor_view(G)
runfile('C:/Users/Oliver/Projects/repos/tropics/graphics.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
divisor_view(G)
runfile('C:/Users/Oliver/Projects/repos/tropics/graphics.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
divisor_view(G)
ax.annotate('hi', (3,3))
_59.set_x(3)
runfile('C:/Users/Oliver/Projects/repos/tropics/graphics.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
divisor_view(G)
paintAll(G5s)
enum_qred(3, G)
enum_qred(3, G, q=0)
enum_qred(3, G, q=0, debug=True)
full_classes(G, 3)
hist(full_classes(G,3))
map( lambda g : hist(full_classes(g,3)), G5s)
list(_)
trigs = filter(lambda h: 8 in h, _)
trigs = list(trigs)
trigs
list(map(lambda g: (g, hist(full_classes(g,3))), G5s))
list(filter(lambda g: 8 in g[1]))
list(filter(lambda g: 8 in g[1], _74))
[p[0] for p in _]
paintAll(_)
CXT
CXT.select_G
paintG(_)
paintG(CXT.select_G)
G = CXT.select_G
hist(full_classes(G, 3))
filter(lambda red, l: span(l) == 8, full_classes(G, 3).items())
list(_)
filter(lambda args: span(args[1]) == 8, full_classes(G, 3).items())
list(_)
divisor_view(G, _)
_88[1]
_88
_88[0]
_88[0][1]
divisor_view(G, _)
divisor_view(G, _88[0])
divisor_view(G, _88[0][0])
paintAll(_77)
import gio
gio.write('genus6.txt', _3)
paintAll(_3)
fa
dsf
CXT.selected_G
CXT
CXT.select_G
CXT.G = _
CXT.G = 3
CXT
G = CXT.select_G
[h for h in full_classes(G, 3) if span(h) == 8]
[h for r,ds in full_classes(G, 3).items() if span(ds) == 8]
[r for r,ds in full_classes(G, 3).items() if span(ds) == 8]
divisor_view(G, _[0])
plt.figure()
divisor_view(G, _[0])
divisor_view(G, _110[0])
[ds for r,ds in full_classes(G, 3).items() if span(ds) == 8]
divs = _[0]
for d in divs:    plt.figure()
for d in divs:    plt.figure()    divisor_view(G, d)    
display_complete(G5s)
display_complete(G5s,3)

##---(Wed Mar 29 12:22:29 2017)---
runfile('C:/Users/Oliver/Projects/repos/tropics/run.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
paintG(G)
runfile('C:/Users/Oliver/Projects/repos/tropics/run.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
paint(G)
paintAll(G5s)
display_complete(G5s)
display_complete(G5s, 3)
G.edges()
nx.is_connected(G)
G.remove_edge(0,4)
G.edges()
G.add_edge(0,4)
G.edges()
runfile('C:/Users/Oliver/Projects/repos/tropics/interactive.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
runfile('C:/Users/Oliver/Projects/repos/tropics/run.py', wdir='C:/Users/Oliver/Projects/repos/tropics')
CXT. G = 3
%%latex\[ a = 3 \]because
%matplotlib notebook
%matplotlib inline
%%latex\[ a = 3 \]because
display(_)
"{0}{1}".format(1,2)
"{0}{1}".format((1,2))

##---(Tue Apr  4 04:23:58 2017)---
a
a =3
3
a
CXT