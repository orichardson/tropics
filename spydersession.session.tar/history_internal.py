# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Wed Feb 22 13:38:19 2017)---
def fire(div, vs, G):
	"""
	div is in vector format, vs is an iterable of vertices. This is the silly,
	non-matrix version of it. To do this properly, do
		div += Q.dot(f)
	"""
	for v, m in vs.items():
		for u in G[v]:
			div[u] += m * len(G[u][v])
			div[v] -= m * len(G[u][v])